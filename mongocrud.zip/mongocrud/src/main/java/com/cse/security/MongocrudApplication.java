package com.cse.security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongocrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(MongocrudApplication.class, args);
	}

}
